#!/bin/sh
# my first script
# demo from: https://grasswiki.osgeo.org/wiki/Shell_scripting
# 2020, Leila

# plot current region settings
g.region -p

# Leave with exit status 0 which means "ok":
exit 0
